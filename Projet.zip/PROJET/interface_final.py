# -*- coding: utf-8 -*-
"""
Created on Tue Jun  6 12:52:19 2023

@author: 33621
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jun  6 12:36:52 2023
Modified on Tue Jun  5 17:02:04 2023
"""

import tkinter as tk
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.decomposition import PCA
# Fonction pour appliquer l'algorithme 1 sur la DataFrame
def algorithm1(data, contamination):
    # Convertir la colonne de date en un format numérique
    date_encoder = LabelEncoder()
    dates_encoded = date_encoder.fit_transform(data.iloc[:, -1])  # Dernière colonne contenant les dates

    # Combinaison des caractéristiques (features) avec les dates encodées
    features = np.concatenate((data.iloc[:, :-1].values, dates_encoded.reshape(-1, 1)), axis=1)
    data.iloc[:,1:6] = data.iloc[:,1:6].replace(np.nan,).astype(float)
    data.iloc[:, -1] = data.iloc[:, -1].replace(np.nan,).astype(float)
    def detecter_aberrations(data):
        # Prétraitement des données
        features = data['Open'].values.reshape(-1, 1)  # Utiliser seulement la colonne "Open"

        # Remplacer les valeurs manquantes par la moyenne de la colonne
        features = np.nan_to_num(features, nan=np.nanmean(features))

        # Standardiser les valeurs
        scaler = StandardScaler()
        features_std = scaler.fit_transform(features)

        # Réseau de neurones
        model = Sequential()
        model.add(Dense(64, activation='relu', input_shape=(1,)))
        model.add(Dense(64, activation='relu'))
        model.add(Dense(1, activation='linear'))

        model.compile(loss='mse', optimizer='adam')

        # Entraînement du modèle
        model.fit(features_std, features_std, epochs=100, batch_size=32, verbose=0)

        # Prédiction des aberrations
        predictions = model.predict(features_std)
        errors = np.abs(predictions - features_std)
        threshold = np.percentile(errors, (1 - contamination) * 100)

        # Détection des aberrations
        outliers = data[errors > threshold]

        return outliers
    # Appel de la fonction pour détecter les données aberrantes
    indices_aberrants = detecter_aberrations(data)

    # Affichage des indices des données aberrantes détectées
    result_label.config(text="Indices des données aberrantes :\n" + str(indices_aberrants))
    
  

def algorithm2(data, seuil):
    # Prétraitement des données
    features = data['Open'].values.reshape(-1, 1)  # Utiliser seulement la colonne "Open"
    labels = data['Close']  # Garder la colonne "Close" pour référence

    # Remplacer les valeurs manquantes par la moyenne de la colonne
    features = np.nan_to_num(features, nan=np.nanmean(features))

    # Standardiser les valeurs
    scaler = StandardScaler()
    features_std = scaler.fit_transform(features)
    def detecter_aberrations(data):
        # Prétraitement des données
        features = data['Open'].values.reshape(-1, 1)  # Utiliser seulement la colonne "Open"
    
        # Remplacer les valeurs manquantes par la moyenne de la colonne
        features = np.nan_to_num(features, nan=np.nanmean(features))
    
        # Standardiser les valeurs
        scaler = StandardScaler()
        features_std = scaler.fit_transform(features)
    
        # Réduire la dimensionnalité avec PCA
        pca = PCA(n_components=1)
        features_pca = pca.fit_transform(features_std)
    
        # Détection des valeurs aberrantes avec Isolation Forest
        outlier_detector = IsolationForest(contamination=seuil)  # Ajuster la contamination en fonction de vos données
        outlier_detector.fit(features_pca)
        outlier_predictions = outlier_detector.predict(features_pca)
    
        # Récupérer les indices des données aberrantes
        outlier_indices = np.where(outlier_predictions == -1)[0]
    
        return outlier_indices

    # Appeler la fonction pour détecter les aberrations
    indices_aberrations = detecter_aberrations(data)
    
    # Affichage des indices des données aberrantes détectées
    result_label.config(text="Indices des données aberrantes :\n" + str(indices_aberrations))

# Fonction pour obtenir la DataFrame et appliquer l'algorithme sélectionné
def get_input_text():
    algorithm = algorithm_var.get()

    if algorithm == "1":
        # Charger la DataFrame à partir du chemin d'accès défini
        data = pd.read_csv(r"C:\Users\33621\Downloads\ORA.PA (3).csv")
        contamination = float(seuil_entry.get())  # Récupérer la contamination depuis l'interface
        algorithm1(data, contamination)
    elif algorithm == "2":
        # Charger la DataFrame à partir du chemin d'accès défini
        data = pd.read_csv(r"C:\Users\33621\Downloads\ORA.PA (3).csv")
        seuil = float(seuil_entry.get())  # Récupérer le seuil depuis l'interface
        algorithm2(data, seuil)
    else:
        result_label.config(text="Aucun algorithme sélectionné")

root = tk.Tk()
root.title("Identification des données aberrantes")

# Zone de choix de l'algorithme
algorithm_label = tk.Label(root, text="Choisir un algorithme :")
algorithm_label.pack()

algorithm_var = tk.StringVar()
algorithm_var.set("")

algorithm1_button = tk.Radiobutton(root, text="Réseau de neurones", variable=algorithm_var, value="1")
algorithm1_button.pack()

algorithm2_button = tk.Radiobutton(root, text="Isolation Forest", variable=algorithm_var, value="2")
algorithm2_button.pack()

# Zone pour saisir le seuil ou la contamination
seuil_label = tk.Label(root, text="Seuil/Contamination :")
seuil_label.pack()

# Zone pour saisir le seuil ou la contamination
o_label = tk.Label(root, text="(le seuil actuel est de 0.04 pour l'isolation forest et 0.05 pour le reseau de neurone si vous souhaitez rajouter une données le seuil augmentez le seuil de 0.01)")
o_label.pack()
seuil_entry = tk.Entry(root)
seuil_entry.pack()

# Bouton pour soumettre le choix de l'algorithme et le seuil/contamination
submit_button = tk.Button(root, text="Soumettre", command=get_input_text)
submit_button.pack()

# Label pour afficher le résultat
result_label = tk.Label(root, text="")
result_label.pack()

root.mainloop()
